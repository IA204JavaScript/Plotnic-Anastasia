import { isValidUrl, sortByTitle } from "./utils.js";

export function renderGallery(images, container) {
  container.innerHTML = "";

  if(images.length === 0) {
    container.innerHTML = "<p>Изображения не найдены.</p>";
    return;
  }

  images.forEach(({id, title, url, category}) => {
    const card = document.createElement("div");
    card.className = "card";
    card.dataset.id = id;

    card.innerHTML = `
      <img src="${url}" alt="${title}" />
      <div class="card-info">
        <h3>${title}</h3>
        <p>Категория: ${category}</p>
        <button class="delete-btn">Удалить</button>
      </div>
    `;

    container.appendChild(card);
  });
}

export function setupEventListeners(state) {
  const gallery = document.getElementById("gallery");
  const modal = document.getElementById("modal");
  const modalImage = document.getElementById("modalImage");
  const modalClose = document.getElementById("modalClose");

  // Открытие модального окна при клике на картинку
  gallery.addEventListener("click", (e) => {
    if(e.target.tagName === "IMG") {
      modalImage.src = e.target.src;
      modal.classList.remove("hidden");
    } 
    // Удаление карточки
    if(e.target.classList.contains("delete-btn")) {
      const card = e.target.closest(".card");
      const id = Number(card.dataset.id);
      state.images = state.images.filter(img => img.id !== id);
      renderGallery(state.images, gallery);
    }
  });

  // Закрытие модального окна
  modalClose.addEventListener("click", () => {
    modal.classList.add("hidden");
    modalImage.src = "";
  });

  modal.addEventListener("click", (e) => {
    if(e.target === modal) {
      modal.classList.add("hidden");
      modalImage.src = "";
    }
  });
}

export function setupForm(state) {
  const form = document.getElementById("addImageForm");
  const titleInput = document.getElementById("imageTitle");
  const urlInput = document.getElementById("imageUrl");
  const categorySelect = document.getElementById("imageCategory");
  const gallery = document.getElementById("gallery");

  form.addEventListener("submit", e => {
    e.preventDefault();

    const title = titleInput.value.trim();
    const url = urlInput.value.trim();
    const category = categorySelect.value;

    // Валидация
    if(title.length < 2) {
      alert("Название должно содержать минимум 2 символа.");
      return;
    }

    if(!isValidUrl(url)) {
      alert("Введите корректный URL.");
      return;
    }

    // Добавляем новое изображение
    const newImage = {
      id: Date.now(),
      title,
      url,
      category
    };

    state.images.push(newImage);
    renderGallery(state.images, gallery);

    form.reset();
  });
}

export function setupFilters(state) {
  const searchInput = document.getElementById("searchInput");
  const categoryFilter = document.getElementById("categoryFilter");
  const sortBtn = document.getElementById("sortAlpha");
  const gallery = document.getElementById("gallery");

  function filterAndRender() {
    let filtered = state.images;

    const searchValue = searchInput.value.toLowerCase();
    if(searchValue) {
      filtered = filtered.filter(img => img.title.toLowerCase().includes(searchValue));
    }

    const categoryValue = categoryFilter.value;
    if(categoryValue !== "all") {
      filtered = filtered.filter(img => img.category === categoryValue);
    }

    renderGallery(filtered, gallery);
  }

  searchInput.addEventListener("input", filterAndRender);
  categoryFilter.addEventListener("change", filterAndRender);

  sortBtn.addEventListener("click", () => {
    state.images = sortByTitle(state.images);
    filterAndRender();
  });
}
