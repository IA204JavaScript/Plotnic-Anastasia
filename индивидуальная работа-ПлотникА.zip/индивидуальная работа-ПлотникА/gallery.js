export function renderGallery(images) {
  const gallery = document.getElementById('gallery');
  gallery.innerHTML = '';

  images.forEach(img => {
    const imageElem = document.createElement('img');
    imageElem.src = img.src;
    imageElem.alt = img.title;
    imageElem.dataset.title = img.title;
    imageElem.classList.add('gallery-img');
    gallery.appendChild(imageElem);
  });
}
