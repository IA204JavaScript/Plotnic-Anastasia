// Проверка валидности URL
export function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch {
    return false;
  }
}

// Сортировка массива изображений по названию (по алфавиту)
export function sortByTitle(images) {
  return [...images].sort((a, b) => a.title.localeCompare(b.title, 'ru'));
}
