export const images = [
  {
    id: 1,
    title: "Горы",
    url: "https://4sport.ua/_upl/2/1555/K2-768x480.jpg",
    category: "Природа"
  },
  {
    id: 2,
    title: "Кошка",
    url: "https://s.afisha.ru/mediastorage/5c/73/68eada5e206e441d9c267533735c.jpg",
    category: "Животные"
  },
  {
    id: 3,
    title: "Ночной город",
    url: "https://m-dekor.by/catalog/4265/main.webp",
    category: "Города"
  }
];
