import { images as initialImages } from "./data.js";
import { renderGallery, setupEventListeners, setupForm, setupFilters } from "./ui.js";

const state = {
  images: [...initialImages]
};

const gallery = document.getElementById("gallery");

renderGallery(state.images, gallery);
setupEventListeners(state);
setupForm(state);
setupFilters(state);
