/**
 * Генерирует уникальный ID
 * @returns {string}
 */
export function generateId() {
  return Date.now().toString();
}

/**
 * Возвращает текущую дату и время в виде строки
 * @returns {string}
 */
export function getCurrentDateTime() {
  return new Date().toLocaleString();
}

/**
 * Форматирует сумму как валюту
 * @param {number} amount - Сумма транзакции
 * @returns {string} Отформатированная строка валюты
 */
export function formatAmount(amount) {
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB" // ← вот здесь меняется валюта
  }).format(amount);
}
