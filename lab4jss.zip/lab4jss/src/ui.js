import { deleteTransaction, transactions } from './transactions.js';
import { calculateTotal } from './index.js';

/**
 * Добавляет строку в таблицу
 * @param {Object} transaction - объект транзакции
 */
export function renderTransaction(transaction) {
  const table = document.querySelector('#table tbody');
  const tr = document.createElement('tr');
  tr.className = transaction.amount >= 0 ? 'income' : 'expense';
  tr.dataset.id = transaction.id;

  const shortDesc = transaction.description.split(' ').slice(0, 4).join(' ');

  tr.innerHTML = `
    <td>${transaction.date}</td>
    <td>${transaction.category}</td>
    <td>${shortDesc}</td>
    <td><button class="delete">Удалить</button></td>
  `;

  table.appendChild(tr);
}

/**
 * Обновляет общую сумму на странице
 */
export function updateTotal() {
  const total = transactions.reduce((sum, t) => sum + Number(t.amount), 0);
  document.getElementById('total').textContent = total;
}

/**
 * Удаляет строку из таблицы и массива
 * @param {string} id
 */
export function removeTransactionRow(id) {
  deleteTransaction(id);
  document.querySelector(`tr[data-id="${id}"]`)?.remove();
  updateTotal();
}

/**
 * Отображает полное описание транзакции
 * @param {string} fullText
 */
export function showFullDescription(fullText) {
  document.getElementById('full-description').textContent = 'Описание: ' + fullText;
}
