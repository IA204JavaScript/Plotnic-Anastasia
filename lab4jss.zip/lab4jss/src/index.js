import { generateId, getCurrentDateTime } from './utils.js';
import { addTransaction, transactions } from './transactions.js';
import {
  renderTransaction,
  updateTotal,
  removeTransactionRow,
  showFullDescription
} from './ui.js';

document.getElementById('form').addEventListener('submit', function(e) {
  e.preventDefault();

  const amount = Number(document.getElementById('amount').value);
  const category = document.getElementById('category').value;
  const description = document.getElementById('description').value;

  if (!description.trim()) return;

  const transaction = {
    id: generateId(),
    date: getCurrentDateTime(),
    amount,
    category,
    description
  };

  addTransaction(transaction);
  renderTransaction(transaction);
  updateTotal();

  this.reset();
});

document.getElementById('table').addEventListener('click', function(e) {
  if (e.target.classList.contains('delete')) {
    const row = e.target.closest('tr');
    const id = row.dataset.id;
    removeTransactionRow(id);
  } else if (e.target.tagName === 'TD') {
    const row = e.target.closest('tr');
    const id = row.dataset.id;
    const t = transactions.find(t => t.id === id);
    if (t) showFullDescription(t.description);
  }
});

/**
 * Подсчитывает и возвращает сумму всех транзакций
 */
export function calculateTotal() {
  updateTotal();
}
