export const transactions = [];

/**
 * Добавляет новую транзакцию в массив
 * @param {Object} transaction - объект транзакции
 */
export function addTransaction(transaction) {
  transactions.push(transaction);
}

/**
 * Удаляет транзакцию по ID
 * @param {string} id - идентификатор транзакции
 */
export function deleteTransaction(id) {
  const index = transactions.findIndex(t => t.id === id);
  if (index !== -1) transactions.splice(index, 1);
}
